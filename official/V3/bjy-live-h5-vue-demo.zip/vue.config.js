module.exports = {
  publicPath: './',
  devServer: {
  }
}
