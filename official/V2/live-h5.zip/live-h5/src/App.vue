<template>
  <div id="app">
    <router-view></router-view>

  </div>
</template>

<script>
export default {
  name: "App",
  data() {
    return {};
  },
};
</script>
<style scoped>
html,
body {
  height: 100%;
}
body {
  font-family: PingFang SC, Lantinghei SC, Microsoft Yahei, Hiragino Sans GB,
    Microsoft Sans Serif, WenQuanYi Micro Hei, sans;
}
#app {
  height: 100%;
}
</style>


