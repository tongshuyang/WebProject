<template>
  <div class="mid">
    <p>模拟列表</p>
    <router-link to="/home">这是入口</router-link>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
};
</script>
<style scoped>
.mid {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  text-align: center;
  padding-top: 200px;
}
</style>