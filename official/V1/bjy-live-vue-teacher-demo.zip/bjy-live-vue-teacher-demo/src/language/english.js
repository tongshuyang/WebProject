/**
 * @file 语言包
 * @author zhaogaoxing
 * 如果需要提供英文版话术，请将隔壁chinese话术翻译写于此文件
 */

// 'use strict'
