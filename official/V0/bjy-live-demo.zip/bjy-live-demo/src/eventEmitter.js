/**
 * @file 自定义事件
 * @author zhaogaoxing
 */
define(function (require, exports) {
    var eventEmitter = BJY.eventEmitter;

    eventEmitter.ACTIVE_LIST_PRESENTER_CHANGE_TRIGGER = 'active_list_presenter_change_trigger';
});