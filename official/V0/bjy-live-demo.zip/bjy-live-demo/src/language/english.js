/**
 * @file 语言包
 * @author zhaogaoxing
 */
define(function (require, exports, module) {
    /**
     * 如果需要提供英文版话术，请将隔壁chinese话术翻译写于此文件
     */
});
