const options = {
  publicPath: '',
  lintOnSave: false
};
module.exports = options;