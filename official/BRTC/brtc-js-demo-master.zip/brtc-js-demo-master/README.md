# brtc-demo

本 Demo 主要用于演示百家云 BRTC 实时音视频(RTC)和实时消息(RTM)的部分功能，如何跑通该 Demo 请详见 [一分钟跑通 DEMO](https://docs.baijiayun.com/open/quick/run_demo/Web.html)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```
