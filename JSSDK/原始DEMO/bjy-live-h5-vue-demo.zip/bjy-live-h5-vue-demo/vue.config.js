module.exports = {
  publicPath: './',
  devServer: {
    https: true
  }
}
