module.exports = {
    publicPath: "./"
};
